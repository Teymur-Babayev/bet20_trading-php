    <!-- Sidebar menu-->
    <div class="app-sidebar__overlay" data-toggle="sidebar"></div>
    <aside class="app-sidebar">
      <div class="app-sidebar__user">
        <div>
          <p class="app-sidebar__user-name">AA</p>
          <p class="app-sidebar__user-designation">bet</p>
        </div>
      </div>
      <ul class="app-menu">
          <li><a class="app-menu__item active" href="SecondPanel.php"><i class="app-menu__icon fa fa-dashboard"></i><span class="app-menu__label">Dashboard</span></a></li>
    
         
          <li><a class="app-menu__item" href="SecondPanel.php"><i class="app-menu__icon fa fa-laptop"></i><span class="app-menu__label">Betting Panel</span></a></li>
          <li><a class="app-menu__item" href="secondBettingHis.php"><i class="app-menu__icon fa fa-pie-chart"></i><span class="app-menu__label">Betting History</span></a></li>
   
      </ul>
    </aside>
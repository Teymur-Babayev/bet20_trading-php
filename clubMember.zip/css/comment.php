@media screen and (max-width: 760px) {
   .logoheader{
    max-width: 100%;
    scroll-snap-type: x mandatory;
    overflow: scroll;
    position: relative;
    margin-left: auto;
    margin-right: auto;
   }
   .comment{
    width: 120%;
    
   }
}
.direction{
    border-right: 1px solid #A9A9A9;
    width: 80px;
    height: 70px;
}
.tages{
  margin-left: 7px; 
  width: 30px; 
  height: 30px;
}
.tagesogol{
  position: absolute;
  left: 13px;
  top: 50px;
  color: #A9A9A9;
  font-size: 12px;
}